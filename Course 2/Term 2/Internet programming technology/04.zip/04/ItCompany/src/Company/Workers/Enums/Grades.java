package Company.Workers.Enums;
public enum Grades {
    Junior,
    Middle,
    Senior
}
