package Company.Workers;

public interface Worker {
     void work();
}
