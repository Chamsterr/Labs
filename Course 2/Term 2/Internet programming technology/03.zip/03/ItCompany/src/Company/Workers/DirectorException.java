package Company.Workers;

public class DirectorException extends Exception {
    public DirectorException(String message) {
        super(message);
    }
}
